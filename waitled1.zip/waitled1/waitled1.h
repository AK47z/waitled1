#ifndef waitled1_h
#define waitled1_h
#include <Arduino.h>
class waitled1{
private : byte x=0,y=0,h,g; int z=0;byte c=0;uint32_t j; 
public :
  // h is pushbutton of led

  void waitms();
  void waits(int b);
 waitled1 (byte pb,byte ledp,int t ,byte l);
};
#endif