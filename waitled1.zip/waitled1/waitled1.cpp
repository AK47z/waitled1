#include <waitled1.h>
#include <Arduino.h>
 
void waitms(){
    if(digitalRead(h)){
      j =millis();
    }

  if (((millis()-j)>=z)||digitalRead(x)){digitalWrite(y,0); }
  
  }

  void waits(int b)
  {
    g=b;
  if(digitalRead(h)){
      j =millis();
    }
      if (((millis()-j)>=(1000*g))||digitalRead(x)){digitalWrite(y,0); }
  }
  
  waitled1 (byte pb,byte ledp,int t ,byte l)
{
 x=pb;
 y=ledp;
 z=t;
 h=l;

  }  
 